1) names: ["Mike", "Joy", "Kate"] 
   names.append(Leah) 
      print(names) 

2) tup1: ("Physics", "Chemistry", "Biology", "Math") 
   tup2: ("Scientist", "Chemist", Biologist", "Mathematician ") 
       print "tup1[0]"

3) myDict = {
     "Rose" = "Red", 
     "Lily" = "White", 
     "Lotus"= "Pink", 
     "Sunflower" = "Yellow"
  } 
     delmyDict("Lotus") 
     printmyDict 
 
